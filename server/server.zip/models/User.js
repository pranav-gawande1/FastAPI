const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const UserSchema = new Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type :String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    is_staff: {
        type: Boolean,
        default: false
    },
    is_active: {
        type: Boolean,
        default: true
    }
})

const UserModel = mongoose.model('users', UserSchema)
module.exports = UserModel;